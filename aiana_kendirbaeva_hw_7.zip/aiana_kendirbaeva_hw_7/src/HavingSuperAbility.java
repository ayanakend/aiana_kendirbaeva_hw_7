public interface HavingSuperAbility {
    void applySuperAbility(String superAbilityType);
}